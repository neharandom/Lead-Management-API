const Lead = require('../models/leadModel');

async function createLeadHandler(req, res, next){
  try{
    const lead = await Lead.createLead(req.body);
    res.status(201).json(lead);
  }catch(err){ next(err); }
}

async function listLeadsHandler(req, res, next){
  try{
    const leads = await Lead.listLeads({ stage: req.query.stage, search: req.query.q, limit: req.query.limit, offset: req.query.offset });
    res.json(leads);
  }catch(err){ next(err); }
}

async function getLeadHandler(req, res, next){
  try{
    const lead = await Lead.getLeadById(req.params.id);
    if (!lead) return res.status(404).json({ error: 'Lead not found' });
    res.json(lead);
  }catch(err){ next(err); }
}

async function updateLeadHandler(req, res, next){
  try{
    const lead = await Lead.updateLead(req.params.id, req.body);
    res.json(lead);
  }catch(err){ next(err); }
}

async function deleteLeadHandler(req, res, next){
  try{
    await Lead.deleteLead(req.params.id);
    res.status(204).send();
  }catch(err){ next(err); }
}

// Notes
async function addNoteHandler(req, res, next){
  try{
    const notes = await Lead.addNote(req.params.id, req.body.author, req.body.content);
    res.status(201).json(notes);
  }catch(err){ next(err); }
}

async function getNotesHandler(req, res, next){
  try{
    const notes = await Lead.getNotes(req.params.id);
    res.json(notes);
  }catch(err){ next(err); }
}

// Simple mock CRM sync (non-blocking)
async function syncToCrmHandler(req, res, next){
  try{
    const lead = await Lead.getLeadById(req.params.id);
    if(!lead) return res.status(404).json({ error: 'Lead not found' });
    res.json({ ok: true, message: `Lead ${lead.id} scheduled for CRM sync` });
  }catch(err){ next(err); }
}

module.exports = { createLeadHandler, listLeadsHandler, getLeadHandler, updateLeadHandler, deleteLeadHandler, addNoteHandler, getNotesHandler, syncToCrmHandler };