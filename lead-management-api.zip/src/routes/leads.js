const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/leadsController');

router.post('/', ctrl.createLeadHandler);
router.get('/', ctrl.listLeadsHandler);
router.get('/:id', ctrl.getLeadHandler);
router.patch('/:id', ctrl.updateLeadHandler);
router.delete('/:id', ctrl.deleteLeadHandler);

router.post('/:id/notes', ctrl.addNoteHandler);
router.get('/:id/notes', ctrl.getNotesHandler);

router.post('/:id/sync', ctrl.syncToCrmHandler);

module.exports = router;