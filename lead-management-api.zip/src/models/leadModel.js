const pool = require('../db');
const { v4: uuidv4 } = require('uuid');

async function createLead(data) {
  const id = uuidv4();
  const sql = `INSERT INTO leads (id,name,email,phone,source,stage,owner,extra) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
  const params = [id, data.name, data.email || null, data.phone || null, data.source || null, data.stage || 'new', data.owner || null, data.extra ? JSON.stringify(data.extra) : null];
  await pool.execute(sql, params);
  return getLeadById(id);
}

async function getLeadById(id) {
  const [rows] = await pool.execute('SELECT * FROM leads WHERE id = ?', [id]);
  return rows[0] || null;
}

async function listLeads({ stage, search, limit = 50, offset = 0 } = {}) {
  let sql = 'SELECT * FROM leads';
  const params = [];
  const where = [];
  if (stage) { where.push('stage = ?'); params.push(stage); }
  if (search) { where.push('(name LIKE ? OR email LIKE ? OR phone LIKE ?)'); params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY updated_at DESC LIMIT ? OFFSET ?';
  params.push(Number(limit), Number(offset));
  const [rows] = await pool.execute(sql, params);
  return rows;
}

async function updateLead(id, patch) {
  const fields = [];
  const params = [];
  for (const key of ['name','email','phone','source','stage','owner','extra']){
    if (patch[key] !== undefined){
      fields.push(`${key} = ?`);
      params.push(key === 'extra' ? JSON.stringify(patch[key]) : patch[key]);
    }
  }
  if (!fields.length) return getLeadById(id);
  params.push(id);
  const sql = `UPDATE leads SET ${fields.join(', ')} WHERE id = ?`;
  await pool.execute(sql, params);
  return getLeadById(id);
}

async function deleteLead(id){
  await pool.execute('DELETE FROM leads WHERE id = ?', [id]);
  return true;
}

// Notes
async function addNote(leadId, author, content){
  const id = uuidv4();
  await pool.execute('INSERT INTO notes (id,lead_id,author,content) VALUES (?, ?, ?, ?)', [id, leadId, author || null, content]);
  const [rows] = await pool.execute('SELECT * FROM notes WHERE lead_id = ? ORDER BY created_at DESC', [leadId]);
  return rows;
}

async function getNotes(leadId){
  const [rows] = await pool.execute('SELECT * FROM notes WHERE lead_id = ? ORDER BY created_at DESC', [leadId]);
  return rows;
}

module.exports = { createLead, getLeadById, listLeads, updateLead, deleteLead, addNote, getNotes };