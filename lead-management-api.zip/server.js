const express = require('express');
const dotenv = require('dotenv');
dotenv.config();

const leadsRouter = require('./src/routes/leads');
const errorHandler = require('./src/middleware/errorHandler');

const app = express();
app.use(express.json());

app.use('/api/leads', leadsRouter);

app.get('/', (req,res) => res.send('Lead Management API is running'));

app.use(errorHandler);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on port ${port}`));